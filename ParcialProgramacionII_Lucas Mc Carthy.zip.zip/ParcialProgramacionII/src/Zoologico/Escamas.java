package Zoologico;

public enum Escamas {
    CICLICAS,
    GRANULARES,
    IMBRICADAS,
    AQUILLADAS
}
