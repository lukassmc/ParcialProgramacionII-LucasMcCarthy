package Zoologico;

public class Ave extends Animales{
    private double envergaduraAlas;
    private boolean vacunado;

    public Ave(String nombre, int edad, double peso, Dieta dieta, double envergaduraAlas) {
        super(nombre, edad, peso, dieta);
        this.envergaduraAlas = envergaduraAlas;
        this.vacunado = false;
    }

    @Override
    public void vacunar() {
        if (vacunado) {
            System.out.println(nombre + " ya estaba vacunado.");
        } else {
            System.out.println(nombre + " ha sido vacunado.");
            vacunado = true; 
        }
    }

    @Override
    public String toString() {
        return "Ave [envergaduraAlas=" + envergaduraAlas + "]";
    }

    





}
