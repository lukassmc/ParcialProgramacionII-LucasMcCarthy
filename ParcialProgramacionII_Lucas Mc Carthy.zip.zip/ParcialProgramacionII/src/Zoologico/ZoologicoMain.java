package Zoologico;

public class ZoologicoMain {
    public static void main(String[] args) throws Exception {

        Zoologico zoologico = new Zoologico();
        
        
        Mamifero elefante = new Mamifero("Elefante", 17, 114.7, Dieta.HERBIVORO);
        Mamifero tigre = new Mamifero("Tigre", 5, 220.5, Dieta.CARNIVORO);
        Mamifero elefante2 = new Mamifero("Elefante", 17, 114.7, Dieta.HERBIVORO);

        Ave cuero = new Ave("Cuervo", 2, 1.54, Dieta.OMNIVORO, 123);
        Ave loro = new Ave("Loro", 3, 0.8, Dieta.OMNIVORO, 50);
        Ave aguila = new Ave("Aguila", 4, 3.0, Dieta.CARNIVORO, 180);

        Reptil dragonDeComodo = new Reptil("DragonDeComodo", 5, 57.6, Dieta.CARNIVORO, Escamas.GRANULARES, "ectotermia");
        Reptil iguana = new Reptil("Iguana", 4, 2.5, Dieta.HERBIVORO, Escamas.AQUILLADAS, "ectotermia");
        Reptil dragonDeComodo2 = new Reptil("DragonDeComodo", 5, 57.6, Dieta.CARNIVORO, Escamas.GRANULARES, "ectotermia");
            
        try{
            zoologico.agregarAnimales(elefante);
            zoologico.agregarAnimales(tigre);
            zoologico.agregarAnimales(elefante2); 
        } catch (AnimalesIgualesException e) {
            System.out.println(e.getMessage());
        }

        try {
            zoologico.agregarAnimales(cuero);
            zoologico.agregarAnimales(loro);
            zoologico.agregarAnimales(aguila);
            zoologico.agregarAnimales(dragonDeComodo);
            zoologico.agregarAnimales(iguana);
            zoologico.agregarAnimales(dragonDeComodo2); 
        } catch (AnimalesIgualesException e) {
            System.out.println(e.getMessage());
        }
        

        System.out.println("----------------------------------------");
        System.out.println("Animales en el zoologico : ");
        zoologico.mostrarAnimales();
        System.out.println("----------------------------------------");
        
        System.out.println("Vacunando animales.....");
        zoologico.vacunarAnimales();
        System.out.println("----------------------------------------");
        
        

    }
}
