package Zoologico;

public class ReptilNoVacunableException extends Exception {
    public ReptilNoVacunableException(String mensaje){
        super(mensaje);
    }
    
    
}
