package Zoologico;
import java.util.ArrayList;
import java.util.List;

public class Zoologico {
    private List<Animales> animales;

    public Zoologico() {
        this.animales = new ArrayList<>();
    }

    public void agregarAnimales(Animales animal) throws AnimalesIgualesException{
        for (Animales a : animales) {
            if (a.nombre.equals(animal.nombre) && a.edad == animal.edad) {
                throw new AnimalesIgualesException("El animal "+ animal.nombre +  " ya existe en el zoológico.");
            }
        }
        animales.add(animal);
    }

    public void mostrarAnimales(){
        if(animales.isEmpty()){
            System.out.println("Antes de mostrar los animales en la lista, debes empezar por agregar uno.");
        }
        else {
            for(Animales animal : animales){
                System.out.println(animal.toString());
            }
        }
    }

    public void vacunarAnimales() throws ReptilNoVacunableException{
        if(animales.isEmpty()){
            System.out.println("Antes de vacunar los animales en la lista, debes empezar por agregar uno.");
        }
        else {
            for (Animales animal : animales) {
                try {
                    animal.vacunar();
                } 
                catch (Exception e) {
                    System.out.println("No se pudo vacunar a " + animal.nombre + ": " + e.getMessage());
                }
            }
            }
        }
    }

