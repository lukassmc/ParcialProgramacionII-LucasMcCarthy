package Zoologico;

public class Mamifero extends Animales{
    private boolean vacunado;
    
    public Mamifero(String nombre, int edad, double peso, Dieta dieta) {
        super(nombre, edad, peso, dieta);
        this.vacunado = false;
    }

    @Override
    public void vacunar() {
        if (vacunado) {
            System.out.println(nombre + " ya estaba vacunado.");
        } else {
            System.out.println(nombre + " ha sido vacunado.");
            vacunado = true; 
        }
    
    }

    @Override
    public String toString() {
        return "Mamifero [peso=" + peso + ", dieta=" + dieta + "]";
    }

    
    
}
