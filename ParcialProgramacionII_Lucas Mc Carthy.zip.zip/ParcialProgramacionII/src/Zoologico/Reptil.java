package Zoologico;

public class Reptil extends Animales{
    private Escamas tipoEscamas;
    private String regulacionTemperatura;
    
    
    public Reptil(String nombre, int edad, double peso, Dieta dieta, Escamas tipoEscamas,
            String regulacionTemperatura) {
        super(nombre, edad, peso, dieta);
        this.tipoEscamas = tipoEscamas;
        this.regulacionTemperatura = regulacionTemperatura;
    }

    @Override
    public String toString() {
        return "Reptil [tipoEscamas=" + tipoEscamas + ", regulacionTemperatura=" + regulacionTemperatura + "]";
    }

    @Override
    public void vacunar() throws ReptilNoVacunableException{
        throw new ReptilNoVacunableException(nombre + " no se puede vacunar, ya que es un reptil."); 
    }
    
    
}
